import React from 'react';
import styles from './Navbar.module.css';

interface NavbarProps {
  totalRegistrations: number;
}

const Navbar: React.FC<NavbarProps> = ({ totalRegistrations }) => {
  return (
    <nav className={styles.navbar}>
      <div className={styles.navContent}>
        <h1 className={styles.title}>FAST Fest 2026</h1>
        <div className={styles.registrationBadge}>
          Registrations: <span className={styles.count}>{totalRegistrations}</span>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
