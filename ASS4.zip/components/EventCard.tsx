import React from 'react';
import styles from './EventCard.module.css';

interface EventCardProps {
  id: number;
  title: string;
  desc: string;
  category: 'Tech' | 'Sports' | 'Arts';
  seats: number;
  isRegistered: boolean;
  onRegister: (eventId: number, eventTitle: string) => void;
}

const EventCard: React.FC<EventCardProps> = ({
  id,
  title,
  desc,
  category,
  seats,
  isRegistered,
  onRegister,
}) => {
  const handleClick = () => {
    if (!isRegistered && seats > 0) {
      onRegister(id, title);
    }
  };

  const getButtonText = () => {
    if (isRegistered) return 'Registered';
    if (seats === 0) return 'Full';
    return 'Register';
  };

  const isButtonDisabled = isRegistered || seats === 0;

  const getCategoryColor = () => {
    switch (category) {
      case 'Tech':
        return styles.techBadge;
      case 'Sports':
        return styles.sportsBadge;
      case 'Arts':
        return styles.artsBadge;
      default:
        return '';
    }
  };

  return (
    <div className={styles.card}>
      <div className={styles.cardHeader}>
        <h3 className={styles.title}>{title}</h3>
        <span className={`${styles.badge} ${getCategoryColor()}`}>{category}</span>
      </div>

      <p className={styles.description}>{desc}</p>

      <div className={styles.seatsInfo}>
        <span className={styles.seatsLabel}>Seats Left:</span>
        <span className={styles.seatsCount}>{seats}</span>
      </div>

      <button
        className={`${styles.button} ${isButtonDisabled ? styles.disabled : styles.active}`}
        onClick={handleClick}
        disabled={isButtonDisabled}
      >
        {getButtonText()}
      </button>
    </div>
  );
};

export default EventCard;
