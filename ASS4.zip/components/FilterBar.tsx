import React from 'react';
import styles from './FilterBar.module.css';

interface FilterBarProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

const FilterBar: React.FC<FilterBarProps> = ({
  selectedCategory,
  onCategoryChange,
  searchQuery,
  onSearchChange,
}) => {
  const categories = ['All', 'Tech', 'Sports', 'Arts'];

  return (
    <div className={styles.filterContainer}>
      <div className={styles.searchSection}>
        <input
          type="text"
          placeholder="Search events by title..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className={styles.searchInput}
        />
      </div>

      <div className={styles.filterSection}>
        <label className={styles.filterLabel}>Filter by Category:</label>
        <div className={styles.buttonGroup}>
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => onCategoryChange(category)}
              className={`${styles.filterButton} ${
                selectedCategory === category ? styles.active : ''
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FilterBar;
