'use client';

import React, { useState, useMemo } from 'react';
import Navbar from '@/components/Navbar';
import EventCard from '@/components/EventCard';
import FilterBar from '@/components/FilterBar';
import Footer from '@/components/Footer';
import styles from './page.module.css';

interface Event {
  id: number;
  title: string;
  desc: string;
  category: 'Tech' | 'Sports' | 'Arts';
  seats: number;
}

const initialEvents: Event[] = [
  {
    id: 1,
    title: 'Coding Competition',
    desc: 'Solve algorithmic problems under time pressure',
    category: 'Tech',
    seats: 2,
  },
  {
    id: 2,
    title: 'Gaming Tournament',
    desc: 'Compete in multiplayer games',
    category: 'Sports',
    seats: 1,
  },
  {
    id: 3,
    title: 'Singing Competition',
    desc: 'Showcase your vocal talent',
    category: 'Arts',
    seats: 3,
  },
  {
    id: 4,
    title: 'Hackathon',
    desc: 'Build a project in 24 hours',
    category: 'Tech',
    seats: 2,
  },
  {
    id: 5,
    title: 'Debate Competition',
    desc: 'Argue and persuade on trending topics',
    category: 'Arts',
    seats: 1,
  },
];

export default function App() {
  const [events, setEvents] = useState<Event[]>(initialEvents);
  const [registeredEvents, setRegisteredEvents] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const totalRegistrations = registeredEvents.length;

  const handleRegister = (eventId: number, eventTitle: string) => {
    if (!registeredEvents.includes(eventTitle)) {
      setEvents((prevEvents) =>
        prevEvents.map((event) =>
          event.id === eventId ? { ...event, seats: Math.max(0, event.seats - 1) } : event
        )
      );
      setRegisteredEvents((prev) => [...prev, eventTitle]);
    }
  };

  const filteredAndSortedEvents = useMemo(() => {
    let filtered = events;

    // Filter by category
    if (selectedCategory !== 'All') {
      filtered = filtered.filter((event) => event.category === selectedCategory);
    }

    // Filter by search query (case-insensitive)
    if (searchQuery.trim()) {
      filtered = filtered.filter((event) =>
        event.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Sort by seats remaining (ascending)
    filtered.sort((a, b) => a.seats - b.seats);

    return filtered;
  }, [events, selectedCategory, searchQuery]);

  const allEventsFull = events.every((event) => event.seats === 0);

  return (
    <div className={styles.container}>
      <Navbar totalRegistrations={totalRegistrations} />

      <main className={styles.main}>
        <div className={styles.statsSection}>
          <div className={styles.statsCard}>
            <h2 className={styles.statsTitle}>Registration Stats</h2>
            <p className={styles.registrationCount}>Total Registrations: {totalRegistrations}</p>
            <div className={styles.registeredEventsList}>
              <h3 className={styles.registeredEventsTitle}>Registered Events:</h3>
              {registeredEvents.length > 0 ? (
                <ul className={styles.eventsList}>
                  {registeredEvents.map((eventTitle, idx) => (
                    <li key={idx} className={styles.eventItem}>
                      • {eventTitle}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className={styles.noEvents}>No events registered yet</p>
              )}
            </div>
          </div>
        </div>

        <FilterBar
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />

        {allEventsFull ? (
          <div className={styles.fullMessage}>
            <h2>All Events Are Full</h2>
            <p>Better luck next time!</p>
          </div>
        ) : (
          <div className={styles.eventsGrid}>
            {filteredAndSortedEvents.map((event) => (
              <EventCard
                key={event.id}
                id={event.id}
                title={event.title}
                desc={event.desc}
                category={event.category}
                seats={event.seats}
                isRegistered={registeredEvents.includes(event.title)}
                onRegister={handleRegister}
              />
            ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
